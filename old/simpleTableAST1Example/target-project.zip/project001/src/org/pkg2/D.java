package org.pkg2;

public class D {
	void md1() {}
	void md2() {}
}
