package org.pkg2;

public class E {
	void me1() {}
	void me2() {}
}
